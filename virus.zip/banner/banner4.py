
import time
import sys
# Set color
R = '\033[31m' # Red
N = '\033[1;37m' # White
G = '\033[32m' # Green
O = '\033[0;33m' # Orange
B = '\033[1;34m' #Blue

def delay_print(s):
    for c in s:
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(0.01)
delay_print
delay_print (""+R+" db    db d888888b d8888b. db    db .d8888. "+B+"  db    db\n")
delay_print (""+R+" 88    88   `88'   88  `8D 88    88 88'  YP "+B+"  `8b  d8'\n")
delay_print (""+R+" Y8    8P    88    88oobY' 88    88 `8bo.   "+B+"   `8bd8' \n")
delay_print (""+R+" `8b  d8'    88    88`8b   88    88   `Y8b. "+B+"   .dPYb.  \n")
delay_print (""+R+"  `8bd8'    .88.   88 `88. 88b  d88 db   8D "+B+"  .8P  Y8. \n")
delay_print (""+R+"   YP    Y888888P 88   YD ~Y8888P' `8888Y'  "+B+" YP    YP "+G+"v1\n")
print                                                     
                                                     
